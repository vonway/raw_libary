#!/bin/bash
n=0
while [ $n -lt 10 ]; do
    let n=n+1
    echo "The Øresund bridge ends in Malmö - $n"
    sleep 1
done
