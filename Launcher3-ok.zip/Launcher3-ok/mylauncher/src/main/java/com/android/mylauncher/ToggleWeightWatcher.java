package com.android.mylauncher;

import android.app.Activity;

public class ToggleWeightWatcher extends Activity {

}
