package com.android.mylauncher;

public interface OnAlarmListener {
    public void onAlarm(Alarm alarm);
}
